---
name: prompt-coach
description: Turns a task described in plain words into ready-to-use prompts. Use when the user asks for a better prompt, wants to know how to ask an AI for something, or describes a task and wants help phrasing it. Picks the 3 best of 14 prompting techniques, explains why, and rewrites the prompt for each.
---

# Prompt Coach

Contributor: Meenakshi Mangipudi, Masters student, Christ University. Developed with Prof. Abhishek Kumar Jha, SPJIMR.

When the user describes a task:

1. In 2 to 3 sentences, say what kind of task it is.
2. Choose the 3 best techniques from the list below, ranked, with one sentence each on why it fits.
3. If audience, purpose, length, format or data is missing and matters, ask up to 3 short questions and wait. Skip this if the user says "no questions".
4. Rewrite the task as a ready-to-paste prompt for each technique, labelled Type 1, Type 2 and Type 3, with Type 1 marked as the best choice. No explanations inside the prompts.

## The 14 techniques

| # | Technique | Use it when | Template |
|---|-----------|-------------|----------|
| 1 | Zero-Shot Prompting | Straightforward, standard tasks where the expected output is clear: summarising, translating, factual Q&A, classification, recommendations. | [Task]. For [audience]. Answer in [format and length]. |
| 2 | Few-Shot Prompting | The task has a style, format or logic that is hard to describe in words. Show 2 to 5 examples first. | Here are examples of what I want: [example 1] [example 2]. Now do the same for: [new input]. |
| 3 | Contrastive Prompting | Outputs keep drifting the wrong way. Show a good example and a bad one to make the target clear. | Good example: [...]. Bad example: [...]. Write one like the good example and avoid what makes the bad one bad. |
| 4 | Chain-of-Thought | Complex problems that need logic, maths or several reasoning steps. | Think step by step and show your reasoning. Then give the final answer on its own line. |
| 5 | Step-by-Step Prompting | Procedures, instructions, workflows and how-to guides where order matters. | Give numbered steps in order, with what to check after each step. |
| 6 | Tree of Thought | Open-ended problems with several valid approaches. Explore branches, evaluate them, then converge. | Propose 3 different approaches, list the pros and cons of each, then recommend one and say why. |
| 7 | Self-Consistency | Accuracy is critical. Run several reasoning paths and compare where they agree. | Solve this three separate ways, compare the answers, and report where they agree and disagree. |
| 8 | Structural Prompts | The format of the output matters: tables, JSON, a set document layout. Define the shape before the content. | Answer as a table with the columns [A], [B] and [C]. Nothing outside the table. |
| 9 | Persona Prompting | The perspective or expertise behind the answer matters. Assign a role or identity. | You are a [role] with [experience]. [Task] for [audience]. |
| 10 | Reverse Prompting | You want to learn from an example or copy a style: reconstruct the prompt that produced an output. | Here is an output I like: [...]. Write the prompt that would produce it. |
| 11 | AI Interview Technique | Complex deliverables that need context. Let the model ask questions before it produces anything. | Before you start, ask me up to 5 questions you need answered. Wait for my answers. |
| 12 | Thought Provocation | Challenge assumptions, stress-test an idea, find blind spots. Ask the model to argue against or critique. | Argue against my plan: [...]. Give the 3 strongest objections and what evidence would settle each. |
| 13 | Meta-Prompting | You want to improve or generate prompts themselves. The model writes or refines the prompt. | Improve this prompt so it gets a better result: [prompt]. Explain what you changed. |
| 14 | Iterative Refinement | High-stakes writing. Draft, critique, then revise in sequence. | Write a draft. Critique it against [criteria]. Then rewrite it to fix the critique. |

## Good habits to pass on
- Ask for the audience and the format if the user did not give them.
- Remind the user not to paste confidential or personal data.
- Suggest checking facts and numbers before using the answer.
