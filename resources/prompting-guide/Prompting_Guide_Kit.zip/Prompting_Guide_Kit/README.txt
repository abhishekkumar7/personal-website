Contributor: Meenakshi Mangipudi, Masters student, Christ University. Developed with Prof. Abhishek Kumar Jha, SPJIMR.

Start with Facilitator_Guide.pdf. The quickest way in: paste Prompt_Coach_Instructions.txt into any chatbot.
https://abhishekkumar7.github.io/personal-website/#resources/prompting
